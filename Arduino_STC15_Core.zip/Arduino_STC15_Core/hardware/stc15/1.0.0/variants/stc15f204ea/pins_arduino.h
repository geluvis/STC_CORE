#ifndef _PINS_ARDUINO_H_
#define _PINS_ARDUINO_H_

#define NUM_DIGITAL_PINS 15

static const uint8_t P0_0 = 0;
static const uint8_t P0_1 = 1;

#endif
