#ifndef ARDUINO_H
#define ARDUINO_H

#include <stdint.h>

void init();

#endif
